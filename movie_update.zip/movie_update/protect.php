<?php 
error_reporting(0);
session_start();

if (empty($_SESSION["user_name"])) {
	header('location:login.php');
	exit();
}
?>