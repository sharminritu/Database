<!DOCTYPE html>
<html>
<body id="main_body" background="tangled3.jpg" >
<title>Watch & Download</title>
<!--tangled-->

<link rel="stylesheet" type="text/css" href="style.css" media="all">

<br><br><br><br><br><br>

<div><h2>to watch the trailer </h2></div>
<a href="https://www.youtube.com/embed/pyOyBVXDJ9Q"><div><h4>click Here! </h4></div></a>


<br>

<div><h2>to download the movie </h2></div>
<a href="https://mycoolmoviez.org/download/7wsfn8m/" ><div><h4>click Here! </h4></div></a>

</body>
</html>