<!DOCTYPE html>
<html>
<title>Movie Details</title>
<body id="main_body" background="inside2.jpg" >

<div id="form_containerlog">
	<!--<div class="fltleft"><img src="sadia.jpg" width="100" height="100" /></div>-->
	
        <h1 class="fltleft">Movie<br> Information...</h1><div style="clear:left"></div>

<link rel="stylesheet" type="text/css" href="style.css" media="all"><br>


<div><h2>Name</h2></div>
<div><h2>Resolution</h2></div>
<div><h2>Size</h2></div>
<div><h2>Release Date</h2></div>
<div><h2>Duration</h2></div>
<div><h2>Genre</h2></div>
<div><h2>Language</h2></div>

<h2>watch <a href="click_link.php">trailer</h2></a>
<h2>to <a href="click_link.php">download </h2></a>

<br><br><br>

<a href="home_page.php"><div><h4>Home</h4></div></a>




<!--a href="click_link.php">Submit<a/>
				<input type="button" onclick="document.location.href = 'http://google.com'" /--> 
</body>
</html>