<!DOCTYPE html>
<html>
<title>Studio</title>
<body id="main_body" background="mermaid.jpg" >

<div id="form_containerlog">
	<!--<div class="fltleft"><img src="sadia.jpg" width="100" height="100" /></div>-->
	
        <h1 class="fltleft">Studio<br> Information...</h1><div style="clear:left"></div>

<link rel="stylesheet" type="text/css" href="style.css" media="all"><br>


<div><h2>Name</h2></div>
<div><h2>Stublished in</h2></div>
<div><h2>Place</h2></div>

<br><br><br>

<a href="home_page.php"><div><h4>Home</h4></div></a>




<!--a href="click_link.php">Submit<a/>
				<input type="button" onclick="document.location.href = 'http://google.com'" /--> 
</body>
</html>