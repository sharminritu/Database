<!DOCTYPE html>
<html>
<title>Index Page</title>
<body id="main_body" background="epic2.jpg" >

<div id="form_containerlog">
	
        <h1 class="fltleft">Movie World</h1><div style="clear:left"></div>


<link rel="stylesheet" type="text/css" href="style.css" media="all">

<br>

<div><h2>Sign Up</h2></div>

<a href="user_create.php">

<div><h4>click Here! </h4></div>

</a><br>

<div><h2>Sign In</h2></div>

<a href="login.php">
<h5> <a href="login.php">Admin Login</a></h5>

<div><h4>click Here! </h4></div>
</a>

<!--a href="click_link.php">Submit<a/>
				<input type="button" onclick="document.location.href = 'http://google.com'" /--> 
</body>
</html>